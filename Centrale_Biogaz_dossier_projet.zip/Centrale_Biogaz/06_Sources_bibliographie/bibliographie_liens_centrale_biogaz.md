# Bibliographie et ressources - Centrale Biogaz

- [APESA (2021) - Etude Pico et Micro-méthanisation](https://www.apesa.fr/wp-content/uploads/2021/08/ETUDE-PICO-ET-MICRO-METHANISATION.pdf)
- [Campus Agronova - P2M Projet pédagogique de méthanisation](https://www.campus-agronova.fr/p2m-projet-pedagogique-de-methanisation/)
- [INERIS/AIDA - Rubrique ICPE 2781](https://aida.ineris.fr/reglementation/2781-installation-methanisation-dechets-non-dangereux-matiere-vegetale-brute-a)
- [Légifrance - Arrêté du 9 avril 2018 (hygiénisation DCT)](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000036830969)
- [GRDF - Guide hygiénisation](https://projet-methanisation.grdf.fr/cms-assets/2021/09/GUIDE-HYGIENISATION-VF-sept21.pdf)
- [ENS de Lyon - Ordres de grandeur énergie/biogaz](https://culturesciencesphysique.ens-lyon.fr/ressource/chiffres-energie-methanisation.xml)
- [Picojoule - association micro-méthanisation low-tech](https://picojoule.org/)
