# Dossier projet - Centrale Biogaz

Dossier constitué le 23/06/2026.

## Contenu
- 00_Index_et_synthese : dossier MASTER avec synthèse, historique, contacts, bibliographie.
- 01_Historique_echanges : dossier destiné à recevoir les exports de conversations ou comptes rendus.
- 02_Dossier_mecene : dossier destiné aux versions du dossier de candidature mécène.
- 03_Contacts_partenaires : carnet d’adresses au format CSV.
- 04_Cadrage_technique : dossier pour cahier des charges, étude de faisabilité, plans, devis.
- 05_Mails_et_courriers : modèles de mails et courriers.
- 06_Sources_bibliographie : liens de référence.
- 07_Annexes_existantes : documents déjà générés ou disponibles localement.

## Note
Cette archive ne contient pas l’export brut intégral de toutes les conversations passées. Elle regroupe une synthèse structurée des échanges disponibles et les documents accessibles dans l’espace de travail.
